package br.edu.univille.br.relacionamentos.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@Entity

public class Musica{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_musica;

    private String titulo_musica;
    private String artista_musica;
    private String genero_musica;
    private String album_musica;

    @ManyToMany(mappedBy = "musicas")
    private List<Playlist> playlists;
}
