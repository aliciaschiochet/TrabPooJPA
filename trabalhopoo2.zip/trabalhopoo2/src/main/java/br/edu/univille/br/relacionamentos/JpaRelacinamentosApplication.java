package br.edu.univille.br.relacionamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaRelacinamentosApplication {

    public static void main(String[] args) {
        SpringApplication.run(JpaRelacinamentosApplication.class, args);
    }
}
