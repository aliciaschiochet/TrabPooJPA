package br.edu.univille.br.relacionamentos.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity

public class Perfil{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_perfil;
    @OneToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;
}