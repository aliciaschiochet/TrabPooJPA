package br.edu.univille.br.relacionamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRelacinamentosApplicationTests {

    @Test
    void contextLoads() {
    }

}
